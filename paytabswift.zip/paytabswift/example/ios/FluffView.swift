//
//  FluffView.swift
//  Runner
//
//  Created by Naqel on 08/02/1441 AH.
//  Copyright © 1441 The Chromium Authors. All rights reserved.
//

import Foundation
 

public class FluffView : NSObject, FlutterPlatformView{
    let frame:CGRect
    let viewId:Int64
    var initialSetupViewController: PTFWInitialSetupViewController!
    
    init(_ frame:CGRect,viewId:Int64,args:Any?) {
        self.frame = frame
        self.viewId = viewId
    }
    
    public func view() -> UIView {
        let cusView = UIView(frame: frame)
        
        let text = UILabel(frame: CGRect(x: 2, y: 2, width: 300, height: 30))
        text.textAlignment = .center
        text.text = "hello this tabs"
        
        cusView.addSubview(text)
        
        
        let paytabBtn = UIButton(frame: CGRect(x: 2, y: 50, width: 300, height: 40))
        paytabBtn.setTitle("Pay Now", for: .normal)
        paytabBtn.setTitleColor( .red , for: .normal)
        
        paytabBtn.backgroundColor = .black
        
        paytabBtn.addTarget(self, action: #selector(self.pressButton(_:)), for: .touchUpInside) //<- use `#selector(...)`
        cusView.addSubview(paytabBtn)

        
        
        return cusView
    }
    
    @objc func pressButton(_ sender: UIButton){ //<- needs `@objc`
        
        
        let bundle = Bundle(url: Bundle.main.url(forResource:  "Resources", withExtension: "bundle")!)
        self.initialSetupViewController = PTFWInitialSetupViewController.init(
            bundle: bundle,
            andWithViewFrame: self.view().frame,
            andWithAmount: 1.0,
            andWithCustomerTitle: "PayTabs Sample App",
            andWithCurrencyCode: "SAR",
            andWithTaxAmount: 0.0,
            andWithSDKLanguage: "en",
            andWithShippingAddress: "Manama",
            andWithShippingCity: "Manama",
            andWithShippingCountry: "BHR",
            andWithShippingState: "Manama",
            andWithShippingZIPCode: "123456",
            andWithBillingAddress: "Manama",
            andWithBillingCity: "Manama",
            andWithBillingCountry: "BHR",
            andWithBillingState: "Manama",
            andWithBillingZIPCode: "12345",
            andWithOrderID: "12345",
            andWithPhoneNumber: "0097333109781",
            andWithCustomerEmail: "rhegazy@paytabs.com",
            andIsTokenization: false,
            andIsPreAuth: false,
            andWithMerchantEmail: "",
            andWithMerchantSecretKey: "",
            andWithAssigneeCode: "SDK",
            andWithThemeColor:UIColor.red,
            andIsThemeColorLight: true)
    

        self.initialSetupViewController.didReceiveBackButtonCallback = {
print("Response Code 1: ")
        }

        self.initialSetupViewController.didStartPreparePaymentPage = {
          // Start Prepare Payment Page
          // Show loading indicator
            print("Response Code2: (responseCode)")
        }
        self.initialSetupViewController.didFinishPreparePaymentPage = {
          // Finish Prepare Payment Page
          // Stop loading indicator
            print("Response Code3: (responseCode)")
        }

        self.initialSetupViewController.didReceiveFinishTransactionCallback = {(responseCode, result, transactionID, tokenizedCustomerEmail, tokenizedCustomerPassword, token, transactionState) in
          print("Response Code: \(responseCode)")
          print("Response Result: \(result)")
          
          // In Case you are using tokenization
          print("Tokenization Cutomer Email: \(tokenizedCustomerEmail)");
          print("Tokenization Customer Password: \(tokenizedCustomerPassword)");
          print("TOkenization Token: \(token)");
        }
    }

    
    
}
