import UIKit
import Flutter


@UIApplicationMain
@objc class AppDelegate: FlutterAppDelegate {
    
  var navigationController:UINavigationController!
  override func application(
    _ application: UIApplication,
    didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
  ) -> Bool {
    GeneratedPluginRegistrant.register(with: self)
    /*let viewfactory = FluffViewFactory()
    registrar(forPlugin: "Kitty")
        .register(viewfactory, withId: "FluffView")*/
    
   let flutterViewController = FlutterViewController() as? UIViewController
    if let flutterViewController = flutterViewController {
        navigationController = UINavigationController(rootViewController: flutterViewController)
    }
    navigationController?.isNavigationBarHidden = true

    window = UIWindow(frame: UIScreen.main.bounds)
    window.rootViewController = PTSRLauncherViewController(nibName: "PTSRLauncherView", bundle: nil)//navigationController
    window.makeKeyAndVisible()
    
    pushExample()
    return true//super.application(application, didFinishLaunchingWithOptions: launchOptions)
  }
    
    func pushExample() {
        /*let viewController = UIViewController()
        viewController.view.backgroundColor = .red
        navigationController?.pushViewController(viewController, animated: true)*/
        
    }
    
    public func moveToSetupViewController() {
           let launcherViewController = PTSRLauncherViewController(nibName: "PTSRLauncherView", bundle: nil)
           
          // self.window?.rootViewController = navigationController?.pushViewController(launcherViewController, animated: true)
       }
}

