//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"
#import <paytabswift/PaytabswiftPlugin.h>

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [PaytabswiftPlugin registerWithRegistrar:[registry registrarForPlugin:@"PaytabswiftPlugin"]];
}

@end
