//
//  MDSplashViewController.h
//  MaitreD
//
//  Created by Humayun on 29/07/2016.
//  Copyright © 2016 Bin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PTFWActivityIndicatorViewController : UIViewController

@end
