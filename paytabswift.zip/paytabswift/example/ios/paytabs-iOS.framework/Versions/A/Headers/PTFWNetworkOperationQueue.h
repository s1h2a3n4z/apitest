//
//  PTFWNetworkOperationQueue.h
//  paytabs-iOS
//
//  Created by PayTabs LLC on 10/8/17.
//  Copyright © 2017 PayTabs LLC. All rights reserved.
//

@interface PTFWNetworkOperationQueue : NSOperationQueue

+ (nonnull instancetype)sharedInstance;

@end
