#import <Flutter/Flutter.h>

@interface PaytabswiftPlugin : NSObject<FlutterPlugin>
@end
