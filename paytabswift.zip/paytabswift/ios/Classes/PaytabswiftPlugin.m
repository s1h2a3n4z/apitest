#import "PaytabswiftPlugin.h"
#import <paytabswift/paytabswift-Swift.h>

@implementation PaytabswiftPlugin
+ (void)registerWithRegistrar:(NSObject<FlutterPluginRegistrar>*)registrar {
  [SwiftPaytabswiftPlugin registerWithRegistrar:registrar];
}
@end
